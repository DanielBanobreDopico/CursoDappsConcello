const HDWalletProvider = require('truffle-hdwallet-provider');
const Web3 = require('web3');
const compile = require('./compile');
const abi = compile.abi;
const bytecode = compile.evm.bytecode.object;

const provider = new HDWalletProvider(
    'output match afford unusual cloud risk govern chair knee reunion cream pottery',
    'https://ropsten.infura.io/v3/9b0b401005e9400690c7670684c2b885'
);

const web3 = new Web3(provider);

const deploy = async() => {
    const accounts = await web3.eth.getAccounts();

    const result = await new web3.eth.Contract(abi)
        .deploy({
            data: bytecode,
            arguments: ['Alberto']
        })
        .send({ from: accounts[0], gas: '1000000' });

    console.log(result);
}
deploy();